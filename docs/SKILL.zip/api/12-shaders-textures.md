# 12 — SkSL Shaders + Noise + Multi-Texture

## SkSL 着色器

支持 SkSL（Skia Shading Language）着色器编译和应用。

| 函数 | 签名 | 说明 |
|------|------|------|
| `shader` | `(shader sksl-source)` | 编译 SkSL 源码，返回 shader 对象 |
| `apply-shader!` | `(apply-shader! shader [graphic])` | 对着色对象应用着色器 |
| `make-uniforms` | `(make-uniforms `((name type) ...)) | 创建 uniform 数据块 |
| `apply-uniforms` | `(apply-uniforms shader uniforms)` | 应用 uniform 数据 |
| `uniform-float` | `(uniform-float val)` | 创建 float uniform 值 |

### 基本示例

```scheme
; 定义一个简单着色器
(define my-shader (shader "
uniform float u_time;
half4 main(float2 xy) {
  float r = sin(xy.x * 0.1 + u_time) * 0.5 + 0.5;
  float g = cos(xy.y * 0.1 + u_time) * 0.5 + 0.5;
  return half4(r, g, 0.75, 1.0);
}"))

; 创建 uniform 数据
(define uniforms (make-uniforms '((u_time float))))
(apply-uniforms my-shader (uniform-float 1.5))

; 应用着色器到图形对象
(apply-shader! my-shader (rect 0 0 200 200 :fill "white"))
(render *canvas* "shader.png")
```

---

## 噪声着色器

| 函数 | 签名 | 说明 |
|------|------|------|
| `noise-fractal` | `(noise-fractal [:seed N] [:octaves N] [:freq F] [:lacunarity L] [:gain G])` | 分形布朗噪声 |
| `noise-turbulence` | `(noise-turbulence [:seed N] [:octaves N] [:freq F] [:lacunarity L] [:gain G])` | 湍流噪声（绝对值变体） |

### 公共参数

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| `:seed` | int | 0 | 随机种子 |
| `:octaves` | int | 4 | 叠加层数 |
| `:freq` | float | 4.0 | 基础频率 |
| `:lacunarity` | float | 2.0 | 频率倍增系数 |
| `:gain` | float | 0.5 | 振幅衰减系数 |

### 示例

```scheme
(define clouds (noise-fractal :seed 42 :octaves 6 :freq 6.0))
(apply-shader! clouds (rect 0 0 256 256 :fill "white"))
(render *canvas* "clouds.png")
```

---

## 多纹理着色器 (bind-textures)

绑定 Skia `uniform shader` child 纹理到 SkSL 着色器。

```scheme
(bind-textures shader-value
  :textures '((slot-name graphic-or-image) ...))
```

| 参数 | 类型 | 说明 |
|------|------|------|
| `shader-value` | shader | 已编译的 SkSL 着色器（必填） |
| `:textures` | list | 纹理绑定列表（必填 kwarg） |

每个绑定项：
| 项 | 说明 |
|---|------|
| `slot-name` | symbol，对应 SkSL 中的 `uniform shader slot_name` |
| `graphic-or-image` | GraphicObject 或 image（渲染成纹理后绑定到插槽） |

### 示例：双纹理合成

```scheme
; 定义着色器
(define blend-shader (shader "
uniform shader base;
uniform shader overlay;
half4 main(float2 xy) {
  half4 b = base.eval(xy);
  half4 o = overlay.eval(xy);
  return half4(mix(b.rgb, o.rgb, o.a), b.a + o.a*(1-b.a));
}"))

; 绑定纹理
(bind-textures blend-shader
  :textures '((base    (rect 0 0 128 128 :fill "red"))
              (overlay (circle 64 64 40 :fill "rgba(0,0,255,0.5)"))))

; 应用
(apply-shader! blend-shader (rect 0 0 128 128))
(render "blend.png")
```

### 示例：组合位图纹理

```scheme
(define tex-shader (shader "
uniform shader tex;
uniform float u_alpha;
half4 main(float2 xy) {
  half4 c = tex.eval(xy);
  c.a *= u_alpha;
  return c;
}"))

; 绑定从文件加载的图像
(bind-textures tex-shader
  :textures '((tex (image "background.png" 0 0 256 256))))

(apply-uniforms tex-shader (uniform-float 0.8))
(apply-shader! tex-shader (rect 0 0 256 256 :fill "white"))
```

---

## 注意事项

- SkSL 语法类似 GLSL，类型用 `half4` / `float2` 等 Skia 类型
- `uniform shader` 声明子纹理插槽，用 `slot.eval(xy)` 采样
- 纹理绑定的 GraphicObject 会先在内部离屏渲染为 SkImage，再绑定为 child shader
- 不支持嵌入其他 PML 着色器的引用，仅支持 SkSL 代码字符串
- 着色器编译错误会返回带行号的错误信息
